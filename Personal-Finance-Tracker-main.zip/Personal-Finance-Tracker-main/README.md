# Personal Finance Tracker

A Python program to track income & expenses, store them in SQLite, analyze spending, and visualize expense categories.

## Features
- Add transactions with date, category, description, and amount
- View all transactions
- Show monthly summaries
- Plot expenses by category (pie chart)

## Requirements
- Python 3.x
- pandas
- matplotlib

## Installation
```bash
pip install -r requirements.txt
